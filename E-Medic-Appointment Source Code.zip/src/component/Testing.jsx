import React from "react";
import Shake from "react-reveal/Shake";

const Testing = () => {
  return (
    <Shake>
      <div
        className=""
        style={{
          marginLeft: "25rem",
          marginTop: "2rem",
          marginBottom: "-7rem",
        }}
      >
        <img src="./1.png" alt="" />
      </div>
    </Shake>
  );
};

export default Testing;
