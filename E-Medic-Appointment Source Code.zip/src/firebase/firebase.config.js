const firebaseConfig = {
  apiKey: "AIzaSyDE7wCERzxcaA-oTwsEAVveOscBa_6HVFU",
  authDomain: "travel-guru-2c0aa.firebaseapp.com",
  projectId: "travel-guru-2c0aa",
  storageBucket: "travel-guru-2c0aa.appspot.com",
  databaseURL:"gs://travel-guru-2c0aa.appspot.com",
  messagingSenderId: "681913570603",
  appId: "1:681913570603:web:a0543e18ffd5821c7c616e",
};

export default firebaseConfig;