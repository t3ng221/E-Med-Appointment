import React from "react";


const Lab = () => {
  return (
    <div>
      
    </div>
  );
};

export default Lab;
