<<<<<<< HEAD
# E-Medic-Appointment
=======
<h2>E-Medic-Appointment</h2>
>>>>>>> origin
After Download the project You have to run from the project directory :

### `npm install`
### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

The page will reload when you make changes.\
You may also see any lint errors in the console.
# Technology Used

<img src="https://i.ibb.co/3zrQSDj/pngaaa-com-4178975.png" width="50px" height="50px"/><span>
<img src="https://i.ibb.co/VDpNkFf/888847.png" width="50px" height="50px"/>
<img src="https://i.ibb.co/K2fbp8r/pngaaa-com-2507930.png" width="50px" height="50px"/>
<img src="https://i.ibb.co/HNMGLwr/pngaaa-com-5670994.png" width="50px" height="50px"/>
<img src="https://i.ibb.co/PD5gmMk/pngaaa-com-5858229.png" width="50px" height="50px"/>
<img src="https://i.ibb.co/z7rxXr4/pngaaa-com-5051155.png" width="50px" height="50px"/>
<img src="https://i.ibb.co/6Jxkrfd/pngaaa-com-5051168.png" width="50px" height="50px"/>
<img src="https://i.ibb.co/zR37vCs/pngaaa-com-6351795.png" width="50px" height="50px"/>
<img src="https://i.ibb.co/Sv4Fgrb/logo.png" width="50px" height="50px"/>
<img src="https://i.ibb.co/tzBJ7hk/68747470733a2f2f76352e676574626f6f7473747261702e636f6d2f646f63732f352e302f6173736574732f6272616e642f.png" width="50px" height="50px"/>
# Tools Used
<img src="https://i.ibb.co/KXt0McZ/heroku.png" width="50px" height="50px"/><span>
<img src="https://cdn.iconscout.com/icon/free/png-256/netlify-3629537-3032320.png" width="50px" height="50px"/>



<h3> Backend-Server : <a href="https://project-101-doctor.herokuapp.com/">E-Medic Server</a></h3>
<ul>REST-Api Routes
   <li><a href="https://project-101-doctor.herokuapp.com/users">/Users</a> </li>
   <li><a href="https://project-101-doctor.herokuapp.com/reg-user-info">/Register-User-Information</a> </li>
   <li><a href="https://project-101-doctor.herokuapp.com/pres-info">/Prescribed-Information</a></li>
   <li><a href="https://project-101-doctor.herokuapp.com/pres-img">/Patient-Prescriptions-Images</a></li>
   <li><a href="https://project-101-doctor.herokuapp.com/users-info">/Patient-Appointment-Card-Information</a></li>
   <li><a href="https://project-101-doctor.herokuapp.com/doctorlist">/All-Registered-Doctor</a></li>
</ul>










